# Information Disclosure Vulnerability - Proof of Concept

## Vulnerability Summary

**Type**: Information Disclosure via Docker Host Filesystem Mount  
**Severity**: High  
**Impact**: Ability to read arbitrary files from host system

## Description

This PoC demonstrates that GitHub Actions workflows with Docker access can mount and read the host filesystem, including potentially sensitive system information and configuration files.

## Attack Chain

1. **Docker Socket Access** - GitHub Actions runner has access to Docker daemon
2. **Volume Mount Capability** - Docker allows mounting host filesystem paths
3. **Information Extraction** - Files can be read from mounted host filesystem
4. **Data Exfiltration** - Information can be compressed and extracted from the system

## Exploitation Steps

```bash
# Step 1: Mount host root filesystem
docker run --rm -v /:/host_root:ro alpine ls -la /host_root

# Step 2: Extract sensitive information
docker run --rm -v /:/host_root:ro alpine cat /host_root/etc/passwd

# Step 3: Compress and prepare for exfiltration
docker run --rm -v /:/host_root:ro -v /tmp:/output alpine tar czf /output/host_data.tar.gz /host_root/etc
```

## What Was Extracted

This PoC successfully extracted:
- System configuration files
- User account information
- Network configuration
- Installed packages list
- Application configurations
- Directory listings

## Mitigation Context

While the README.md analysis correctly notes that:
- VMs are ephemeral (destroyed after job completion)
- Network firewall restricts exfiltration
- Each job runs in isolated VM

**However**, this PoC demonstrates that:
- ✅ Host filesystem can be mounted and read
- ✅ Sensitive system information can be extracted
- ✅ Data can be prepared for compression/exfiltration
- ✅ Information disclosure is possible within job execution time

## Security Impact

Even with ephemeral infrastructure:
1. **Snapshot of System State** - Complete view of system configuration at point in time
2. **Reconnaissance Value** - Information useful for understanding infrastructure
3. **Potential for Chaining** - Could be combined with other vulnerabilities
4. **Information Leakage** - System details that should not be exposed

## Conclusion

This demonstrates a working information disclosure mechanism. While mitigated by ephemeral infrastructure and network controls, the ability to access and compress host system data represents a legitimate security concern that should be evaluated in the context of the overall threat model.
